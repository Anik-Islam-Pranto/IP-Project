package com.example.weather_dashboard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

@SpringBootApplication
public class WeatherDashboardApplication extends SpringBootServletInitializer {

    // This method is required for WAR deployment on external Tomcat
    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
        return builder.sources(WeatherDashboardApplication.class);
    }

    public static void main(String[] args) {
        SpringApplication.run(WeatherDashboardApplication.class, args);
    }
}
