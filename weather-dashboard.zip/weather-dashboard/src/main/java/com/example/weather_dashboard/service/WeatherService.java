
package com.example.weather_dashboard.service;

import com.example.weather_dashboard.model.Weather;
import com.example.weather_dashboard.model.Forecast;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.*;

@Service
public class WeatherService {

    private static final String API_KEY = "5a12275098a4b6ccf7024517e23379f3";
    private static final String CURRENT_URL =
            "https://api.openweathermap.org/data/2.5/weather?q=%s&units=metric&appid=" + API_KEY;
    private static final String FORECAST_URL =
            "https://api.openweathermap.org/data/2.5/forecast?q=%s&units=metric&appid=" + API_KEY;

    public Weather getWeather(String city) {
        RestTemplate restTemplate = new RestTemplate();
        String jsonResponse = restTemplate.getForObject(String.format(CURRENT_URL, city), String.class);

        JSONObject obj = new JSONObject(jsonResponse);
        Weather weather = new Weather();
        weather.setLocation(obj.getString("name"));
        weather.setTemperature(obj.getJSONObject("main").getDouble("temp"));
        weather.setHumidity(obj.getJSONObject("main").getInt("humidity"));
        weather.setWindSpeed(obj.getJSONObject("wind").getDouble("speed"));
        weather.setDescription(obj.getJSONArray("weather").getJSONObject(0).getString("description"));

        return weather;
    }

    public List<Forecast> getForecast(String city) {
        RestTemplate restTemplate = new RestTemplate();
        String jsonResponse = restTemplate.getForObject(String.format(FORECAST_URL, city), String.class);

        JSONObject obj = new JSONObject(jsonResponse);
        JSONArray list = obj.getJSONArray("list");

        List<Forecast> forecasts = new ArrayList<>();
        for (int i = 0; i < list.length(); i += 8) { // every 8 * 3h = 1 day
            JSONObject dayObj = list.getJSONObject(i);
            Forecast f = new Forecast();
            f.setDate(dayObj.getString("dt_txt").split(" ")[0]);
            f.setTemperature(dayObj.getJSONObject("main").getDouble("temp"));
            f.setDescription(dayObj.getJSONArray("weather").getJSONObject(0).getString("description"));
            forecasts.add(f);
        }
        return forecasts;
    }
}

