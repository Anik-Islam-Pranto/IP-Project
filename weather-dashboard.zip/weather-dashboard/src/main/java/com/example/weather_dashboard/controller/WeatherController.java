

package com.example.weather_dashboard.controller;

import com.example.weather_dashboard.model.*;
import com.example.weather_dashboard.service.WeatherService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
public class WeatherController {

    @Autowired
    private WeatherService weatherService;

    @GetMapping("/")
    public String getWeather(@RequestParam(value = "city", required = false) String city, Model model) {
        if (city != null && !city.isEmpty()) {
            Weather weather = weatherService.getWeather(city);
            List<Forecast> forecast = weatherService.getForecast(city);
            model.addAttribute("city", city);
            model.addAttribute("weather", weather);
            model.addAttribute("forecast", forecast);
        }
        return "index";
    }
}

